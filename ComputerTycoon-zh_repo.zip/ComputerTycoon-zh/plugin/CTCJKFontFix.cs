using System;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using Il2CppInterop.Runtime;
using TMPro;
using UnityEngine;

namespace CTCJKFontFix
{
    [BepInPlugin("yikai.ct.cjkfontfix", "CT CJK Font Fix", "0.3.2")]
    public class Plugin : BasePlugin
    {
        internal static ManualLogSource L;
        internal static bool WmEnabled = true;
        internal static string WmText = "简体中文汉化 by Yikai（非官方汉化，免费分享）";
        internal static float WmSize = 26f;
        internal static string WmColor = "#C8C8FF";
        internal static bool SafeLoad = true;
        internal static bool OnlyFirstLoad = false;
        internal static float ResumeDelay = 2.0f;
        public override void Load()
        {
            L = Log;
            try
            {
                WmEnabled = Config.Bind("Watermark", "Enabled", true, "在加载画面右下角显示汉化水印").Value;
                WmText = Config.Bind("Watermark", "Text", WmText, "水印文字，可自行修改").Value;
                WmSize = Config.Bind("Watermark", "FontSize", WmSize, "字号").Value;
                WmColor = Config.Bind("Watermark", "Color", WmColor, "颜色（十六进制）").Value;
                SafeLoad = Config.Bind("Fixes", "PauseTranslationWhileLoading", true, "加载/读档期间暂停翻译，避免读档后日期变成 1970 等问题").Value;
                OnlyFirstLoad = Config.Bind("Fixes", "OnlyFirstLoad", false, "只在每次启动游戏后的第一次加载时暂停（问题只出现在第一次加载）").Value;
                ResumeDelay = Config.Bind("Fixes", "ResumeDelaySeconds", 2.0f, "加载画面消失后多少秒恢复翻译").Value;
            }
            catch (Exception e) { L.LogWarning("[CJK] config: " + e.Message); }
            L.LogInfo("[CJK] plugin loaded, adding component");
            AddComponent<FontFixer>();
        }
    }

    public class FontFixer : MonoBehaviour
    {
        public FontFixer(IntPtr ptr) : base(ptr) { }

        static ManualLogSource L => Plugin.L;
        int frame;
        bool tried;
        TMP_FontAsset cjk;
        float nextAttach;
        float nextWm;
        TMP_Text host;
        GameObject wm;
        bool wmFailed;

        static bool IsLoader(string t) =>
            t != null && (t.StartsWith("FOUND COMPUTER TYCOON", StringComparison.Ordinal) || t.Contains("COMMANDOR 64"));

        // ---------- XUnity toggle (same as Alt+T) ----------
        static object xua; static MethodInfo xuaToggle; static FieldInfo xuaMode; static bool xuaTried;
        static bool XuaReady()
        {
            if (xua != null) return true;
            if (xuaTried) return false;
            xuaTried = true;
            try
            {
                var asm = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == "XUnity.AutoTranslator.Plugin.Core");
                var t = asm?.GetType("XUnity.AutoTranslator.Plugin.Core.AutoTranslationPlugin");
                var cur = t?.GetField("Current", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                xua = cur?.GetValue(null);
                xuaToggle = t?.GetMethod("ToggleTranslation", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Type.EmptyTypes, null);
                xuaMode = t?.GetField("_isInTranslatedMode", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (xua == null || xuaToggle == null || xuaMode == null) { L.LogWarning("[CJK] XUnity toggle not found (inst=" + (xua != null) + ", toggle=" + (xuaToggle != null) + ", mode=" + (xuaMode != null) + ")"); xua = null; return false; }
                return true;
            }
            catch (Exception e) { L.LogWarning("[CJK] XUnity toggle init: " + e.Message); xua = null; return false; }
        }
        static bool XuaOn() => (bool)xuaMode.GetValue(xua);
        static void XuaToggle() => xuaToggle.Invoke(xua, null);

        bool pausedByUs;
        bool firstLoadDone;
        float resumeAt = -1f;

        void LoaderTick()
        {
            if (wmFailed) return;
            try
            {
                bool active = false;
                if (host != null)
                {
                    try { active = host != null && host.gameObject.activeInHierarchy && IsLoader(host.text); } catch { active = false; }
                    if (!active)
                    {
                        try { if (wm != null) Destroy(wm); } catch { }
                        wm = null; host = null;
                    }
                }
                if (host == null)
                {
                    var arr = UnityEngine.Object.FindObjectsOfType(Il2CppType.Of<TMP_Text>());
                    foreach (var o in arr)
                    {
                        var t = o.TryCast<TMP_Text>();
                        if (t == null) continue;
                        string s;
                        try { s = t.text; } catch { continue; }
                        if (!IsLoader(s)) continue;
                        host = t; active = true;
                        L.LogInfo("[CJK] loading screen detected");
                        if (Plugin.WmEnabled) { try { wm = CreateWatermark(t.transform.parent != null ? t.transform.parent : t.transform); } catch (Exception e) { L.LogWarning("[CJK] watermark: " + e.Message); } }
                        break;
                    }
                }
                if (!Plugin.SafeLoad || !XuaReady()) return;
                if (active)
                {
                    resumeAt = -1f;
                    if (!pausedByUs && !(Plugin.OnlyFirstLoad && firstLoadDone) && XuaOn()) { XuaToggle(); pausedByUs = true; L.LogInfo("[CJK] translation paused during loading"); }
                }
                else if (pausedByUs)
                {
                    if (resumeAt < 0f) resumeAt = Time.realtimeSinceStartup + Plugin.ResumeDelay;
                    else if (Time.realtimeSinceStartup >= resumeAt)
                    {
                        if (!XuaOn()) XuaToggle();
                        pausedByUs = false; resumeAt = -1f; firstLoadDone = true;
                        L.LogInfo("[CJK] translation resumed after loading");
                    }
                }
            }
            catch (Exception e) { wmFailed = true; L.LogError("[CJK] loader tick disabled after error: " + e); }
        }

        GameObject CreateWatermark(Transform parent)
        {
            var go = new GameObject("CT_ZH_Watermark");
            go.transform.SetParent(parent, false);
            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.font = cjk;
            tmp.text = Plugin.WmText;
            tmp.fontSize = Plugin.WmSize;
            Color c = new Color(0.78f, 0.78f, 1f, 0.9f);
            try
            {
                var h = Plugin.WmColor.TrimStart('#');
                if (h.Length >= 6)
                    c = new Color(Convert.ToInt32(h.Substring(0, 2), 16) / 255f, Convert.ToInt32(h.Substring(2, 2), 16) / 255f, Convert.ToInt32(h.Substring(4, 2), 16) / 255f, 0.9f);
            }
            catch { }
            tmp.color = c;
            tmp.alignment = TextAlignmentOptions.BottomRight;
            try { tmp.enableWordWrapping = false; } catch { }
            tmp.raycastTarget = false;
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(1f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(1f, 0f);
            rt.anchoredPosition = new Vector2(-24f, 16f);
            rt.sizeDelta = new Vector2(1400f, 80f);
            go.transform.SetAsLastSibling();
            return go;
        }
        const string Probe = "新游戏读取设置关于信息退出";

        public void Update()
        {
            frame++;
            if (frame < 120) return;
            try
            {
                if (!tried)
                {
                    tried = true;
                    L.LogInfo("[CJK] start, TMP_Settings present: " + (TMP_Settings.instance != null));
                    cjk = Build();
                    if (cjk == null) { L.LogError("[CJK] ALL STRATEGIES FAILED"); return; }
                    try { cjk.hideFlags = HideFlags.DontUnloadUnusedAsset; } catch (Exception e) { L.LogWarning("[CJK] hideFlags: " + e.Message); }
                    try { cjk.name = "CT_CJK_Fallback"; } catch { }
                }
                if (cjk != null && Time.realtimeSinceStartup >= nextAttach)
                {
                    nextAttach = Time.realtimeSinceStartup + 3f;
                    Attach();
                }
                if (cjk != null && (Plugin.WmEnabled || Plugin.SafeLoad) && Time.realtimeSinceStartup >= nextWm)
                {
                    nextWm = Time.realtimeSinceStartup + (host == null ? 0.25f : 0.1f);
                    LoaderTick();
                }
            }
            catch (Exception e) { L.LogError("[CJK] Update error: " + e); }
        }

        static string[] FontFiles()
        {
            var list = new System.Collections.Generic.List<string>();
            try
            {
                var dir = Path.Combine(Paths.PluginPath, "CJKFontFix");
                if (Directory.Exists(dir))
                    list.AddRange(Directory.GetFiles(dir).Where(f => f.EndsWith(".ttf", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".otf", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".ttc", StringComparison.OrdinalIgnoreCase)));
            }
            catch { }
            var win = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
            if (string.IsNullOrEmpty(win)) win = @"C:\Windows\Fonts";
            foreach (var n in new[] { "msyh.ttc", "msyh.ttf", "simhei.ttf", "Deng.ttf", "simsun.ttc", "NotoSansSC-VF.ttf" })
            {
                var p = Path.Combine(win, n);
                if (File.Exists(p)) list.Add(p);
            }
            L.LogInfo("[CJK] font files found: " + string.Join(" | ", list));
            return list.ToArray();
        }

        static MethodInfo[] Creators() =>
            typeof(TMP_FontAsset).GetMethods(BindingFlags.Public | BindingFlags.Static).Where(m => m.Name == "CreateFontAsset").ToArray();

        static object[] Args(MethodInfo m, object first, int faceIndex)
        {
            var ps = m.GetParameters();
            var a = new object[ps.Length];
            for (int i = 0; i < ps.Length; i++)
            {
                var n = ps[i].Name; var t = ps[i].ParameterType;
                if (i == 0) a[i] = first;
                else if (n == "faceIndex") a[i] = faceIndex;
                else if (n == "samplingPointSize") a[i] = 64;
                else if (n == "atlasPadding") a[i] = 6;
                else if (n == "renderMode") a[i] = Enum.ToObject(t, 4165); // GlyphRenderMode.SDFAA
                else if (n == "atlasWidth" || n == "atlasHeight") a[i] = 2048;
                else if (n == "atlasPopulationMode") a[i] = Enum.ToObject(t, 1); // Dynamic
                else if (n == "enableMultiAtlasSupport") a[i] = true;
                else a[i] = ps[i].HasDefaultValue ? ps[i].DefaultValue : (t.IsValueType ? Activator.CreateInstance(t) : null);
            }
            return a;
        }

        static TMP_FontAsset Check(string label, object r)
        {
            var fa = r as TMP_FontAsset;
            if (fa == null) { L.LogWarning("[CJK] " + label + " -> null"); return null; }
            bool ok = false;
            try { ok = fa.HasCharacter('游', false, true); } catch (Exception e) { L.LogWarning("[CJK] " + label + " HasCharacter threw: " + e.Message); }
            L.LogInfo("[CJK] " + label + " -> created, renders CJK: " + ok);
            return ok ? fa : null;
        }

        static TMP_FontAsset Try(string label, Func<object> f)
        {
            try { return Check(label, f()); }
            catch (Exception e)
            {
                var ie = e is TargetInvocationException && e.InnerException != null ? e.InnerException : e;
                L.LogWarning("[CJK] " + label + " FAILED: " + ie.GetType().Name + ": " + ie.Message);
                return null;
            }
        }

        static TMP_FontAsset Build()
        {
            var cs = Creators();
            L.LogInfo("[CJK] CreateFontAsset overloads: " + string.Join(" ; ", cs.Select(m => "(" + string.Join(",", m.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name)) + ")")));
            var files = FontFiles();
            TMP_FontAsset fa;

            // S1: TMP from file path (FontEngine.LoadFontFace(path))
            var byPath = cs.Where(m => m.GetParameters()[0].Name == "fontFilePath").OrderByDescending(m => m.GetParameters().Length).FirstOrDefault();
            if (byPath != null)
                foreach (var f in files)
                    if ((fa = Try("S1 path " + Path.GetFileName(f), () => byPath.Invoke(null, Args(byPath, f, 0)))) != null) return fa;

            // S2: TMP from OS family name
            var byFamily = cs.FirstOrDefault(m => m.GetParameters()[0].Name == "familyName");
            if (byFamily != null)
                foreach (var fam in new[] { "Microsoft YaHei", "Microsoft YaHei UI", "SimHei", "DengXian", "Noto Sans SC" })
                    if ((fa = Try("S2 family " + fam, () => byFamily.Invoke(null, new object[] { fam, "Regular", 64 }))) != null) return fa;

            // S3/S4: UnityEngine.Font then TMP from Font
            var byFont = cs.Where(m => m.GetParameters()[0].Name == "font").OrderByDescending(m => m.GetParameters().Length).FirstOrDefault();
            if (byFont != null)
            {
                foreach (var fam in new[] { "Microsoft YaHei", "SimHei" })
                    if ((fa = Try("S3 OSFont " + fam, () => { var uf = Font.CreateDynamicFontFromOSFont(fam, 64); return byFont.Invoke(null, Args(byFont, uf, 0)); })) != null) return fa;
                foreach (var f in files)
                    if ((fa = Try("S4 new Font(path) " + Path.GetFileName(f), () => { var uf = new Font(); var cf = typeof(Font).GetMethod("Internal_CreateFontFromPath", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic); if (cf == null) throw new Exception("Internal_CreateFontFromPath not found"); cf.Invoke(null, new object[] { uf, f }); return byFont.Invoke(null, Args(byFont, uf, 0)); })) != null) return fa;
            }
            return null;
        }

        void Attach()
        {
            int added = 0;
            try
            {
                var s = TMP_Settings.fallbackFontAssets;
                if (s != null && !s.Contains(cjk)) { s.Add(cjk); added++; }
            }
            catch (Exception e) { L.LogWarning("[CJK] TMP_Settings fallback: " + e.Message); }

            try
            {
                var all = Resources.FindObjectsOfTypeAll(Il2CppType.Of<TMP_FontAsset>());
                foreach (var o in all)
                {
                    var f = o.TryCast<TMP_FontAsset>();
                    if (f == null || f.Pointer == cjk.Pointer) continue;
                    var tbl = f.fallbackFontAssetTable;
                    if (tbl == null) { tbl = new Il2CppSystem.Collections.Generic.List<TMP_FontAsset>(); f.fallbackFontAssetTable = tbl; }
                    if (!tbl.Contains(cjk)) { tbl.Add(cjk); added++; L.LogInfo("[CJK] fallback attached to " + f.name); }
                }
            }
            catch (Exception e) { L.LogWarning("[CJK] attach: " + e.Message); }

            if (added > 0)
            {
                try
                {
                    var texts = Resources.FindObjectsOfTypeAll(Il2CppType.Of<TMP_Text>());
                    int n = 0;
                    foreach (var o in texts) { var t = o.TryCast<TMP_Text>(); if (t == null) continue; t.havePropertiesChanged = true; t.SetAllDirty(); n++; }
                    L.LogInfo("[CJK] refreshed " + n + " TMP texts");
                }
                catch (Exception e) { L.LogWarning("[CJK] refresh: " + e.Message); }
            }
        }
    }
}

namespace System.Runtime.CompilerServices
{
    [AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
    internal sealed class RefSafetyRulesAttribute : Attribute { public RefSafetyRulesAttribute(int version) { Version = version; } public readonly int Version; }
}
